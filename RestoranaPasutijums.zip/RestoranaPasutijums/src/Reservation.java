
import java.util.Date;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Milena.Kurtisa
 */
import java.util.Date;

public class Reservation {
    public Date date;
    public String guess; 
    public String time;
    private Boolean status;

    public void cancelReservation(String date, String guess, String time) {
    }

    public void createReservation() {
    }

    private Boolean checkStatus() {
        return status;
    }
}