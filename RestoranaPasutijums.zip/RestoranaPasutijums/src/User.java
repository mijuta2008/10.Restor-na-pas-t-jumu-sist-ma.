/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Milena.Kurtisa
 */
public class User {
    private String name;
    private String login;
    private String password;
    
    private boolean enter(String login, String password){ 
return true; 
}
    private boolean User(String login, String password){
        
        this.name= name;
        this.login=login;
        this.password= password;
        return false;
    }




}      

