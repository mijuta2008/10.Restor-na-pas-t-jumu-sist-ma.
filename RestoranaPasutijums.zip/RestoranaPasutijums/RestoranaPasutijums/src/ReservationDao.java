
import java.util.Date;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Milena.Kurtisa
 */
public class ReservationDao {
    
    public void createReservation(String Reservation){
    }
    public boolean cancelReservation(Date date , String time){
        return false;
    }
}
