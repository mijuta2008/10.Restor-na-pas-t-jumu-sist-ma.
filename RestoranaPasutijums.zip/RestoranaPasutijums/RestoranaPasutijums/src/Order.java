/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Date;

/**
 *
 * @author Milena.Kurtisa
 */
import java.util.Date;

public class Order {
    private Date date;
    private boolean status;
    private Double totalPrice;
    
    public String addDish(String nameDish, Double price, String description) {
        return null;
    }
    
    public double calculate() {
        return totalPrice;    
    }
    
    public void changeStatus(boolean status) {
        this.status = status;
    }
}
