/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Date;

/**
 *
 * @author Milena.Kurtisa
 */
public class Order {
    public Date date;
    public boolean Status;
    public Double totalPrice;
    
    public String addDish(String nameDish, Double price, String description){
        return null;
    }
    public double calculate(){
        return totalPrice;        
    }
    public void changeStatus(boolean Status){
    }
}
