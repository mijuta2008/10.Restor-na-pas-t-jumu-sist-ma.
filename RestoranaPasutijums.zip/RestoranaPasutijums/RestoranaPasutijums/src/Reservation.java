
import java.util.Date;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Milena.Kurtisa
 */
public class Reservation extends Order {
    
    public Date date;
    public String guess;
    public String time;
    public boolean Status;
    
    public void cancelReservation(Date date,String guess, String time){
    }      
    
  public void createReseration(){
  }
  public boolean checkStatus(){
      
        return Status;
        
  }
}
