/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Milena.Kurtisa
 */
public class Bill {
    public double totalpayment;
    public boolean paymentStatus;
    public String date;
    
    public double calculateTotal(){
        return totalpayment;
    }
    public boolean changePaymentStatus(boolean paymentStatus){
        return paymentStatus;
    
    }
    public void pay(){
    }
}
