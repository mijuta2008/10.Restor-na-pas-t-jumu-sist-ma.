
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Milena.Kurtisa
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserDao {

    static final String DB_URL =
        "jdbc:derby://localhost:1527/RestoranaPasutijums";
    static final String DB_USER = "dbuser";
    static final String DB_PASSWD = "dbuser";

    public int registerUser(
            String name,
            String login,
            String password) throws SQLException {

        try (Connection conn = DriverManager.getConnection(
                DB_URL, DB_USER, DB_PASSWD)) {

            // Pārbauda, vai e-pasts jau ir reģistrēts
            String checkSql =
                "SELECT USER_ID FROM USERS WHERE LOGIN = ?";

            try (PreparedStatement check =
                    conn.prepareStatement(checkSql)) {

                check.setString(1, login);

                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next()) {
                        throw new SQLException(
                            "Šis e-pasts jau ir reģistrēts!"
                        );
                    }
                }
            }

            // Atrod nākamo pieejamo ID
            int newId = 1;

            String idSql = "SELECT MAX(USER_ID) FROM USERS";

            try (Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(idSql)) {

                if (rs.next()) {
                    newId = rs.getInt(1) + 1;
                }
            }

            // Saglabā lietotāju
            String insertSql =
                "INSERT INTO USERS "
                + "(USER_ID, NAME, LOGIN, PASSWORD, ROLE) "
                + "VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement ps =
                    conn.prepareStatement(insertSql)) {

                ps.setInt(1, newId);
                ps.setString(2, name);
                ps.setString(3, login);
                ps.setString(4, password);
                ps.setString(5, "lietotajs");

                ps.executeUpdate();
            }

            return newId;
        }
    }
}