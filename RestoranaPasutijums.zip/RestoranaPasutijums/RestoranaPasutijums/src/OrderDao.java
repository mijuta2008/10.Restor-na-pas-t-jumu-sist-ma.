
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Milena.Kurtisa
 */

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OrderDao {

    static final String DB_URL =
        "jdbc:derby://localhost:1527/RestoranaPasutijums";
    static final String DB_USER = "dbuser";
    static final String DB_PASSWD = "dbuser";

    // Jauna pasūtījuma izveide
    public int createOrder(int userId) throws SQLException {

        try (Connection conn = DriverManager.getConnection(
                DB_URL, DB_USER, DB_PASSWD)) {

            int orderId = 1;

            String idSql = "SELECT MAX(ORDER_ID) FROM ORDERS";

            try (PreparedStatement ps = conn.prepareStatement(idSql);
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    orderId = rs.getInt(1) + 1;
                }
            }

            String sql = "INSERT INTO ORDERS "
                + "(ORDER_ID, DATE, STATUS, TOTAL_PRICE, PAYMENT_STATUS, USER_ID) "
                + "VALUES (?, CURRENT_DATE, ?, ?, ?, ?)";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, orderId);
                ps.setString(2, "In progress");
                ps.setBigDecimal(3, BigDecimal.ZERO);
                ps.setBoolean(4, false);
                ps.setInt(5, userId);

                ps.executeUpdate();
            }

            return orderId;
        }
    }

    // Ēdiena pievienošana grozam
    public void addDish(int orderId, int dishId) throws SQLException {

        if (orderId <= 0) {
            throw new SQLException("Vispirms jāizveido pasūtījums!");
        }

        try (Connection conn = DriverManager.getConnection(
                DB_URL, DB_USER, DB_PASSWD)) {

            String updateSql =
                "UPDATE ORDER_DISHES "
                + "SET QUANTITY = QUANTITY + 1 "
                + "WHERE ORDER_ID = ? AND DISH_ID = ?";

            try (PreparedStatement ps =
                    conn.prepareStatement(updateSql)) {

                ps.setInt(1, orderId);
                ps.setInt(2, dishId);

                int updated = ps.executeUpdate();

                if (updated == 0) {
                    String insertSql =
                        "INSERT INTO ORDER_DISHES "
                        + "(ORDER_ID, DISH_ID, QUANTITY, PRICE) "
                        + "SELECT ?, DISH_ID, 1, PRICE "
                        + "FROM DISHES WHERE DISH_ID = ?";

                    try (PreparedStatement insert =
                            conn.prepareStatement(insertSql)) {

                        insert.setInt(1, orderId);
                        insert.setInt(2, dishId);

                        if (insert.executeUpdate() == 0) {
                            throw new SQLException(
                                "Ēdiens ar šo ID nav atrasts!"
                            );
                        }
                    }
                }
            }
        }

        updateTotal(orderId);
    }

    // Pasūtījuma kopsummas pārrēķins
    public BigDecimal updateTotal(int orderId) throws SQLException {

        String sql =
            "SELECT COALESCE(SUM(QUANTITY * PRICE), 0) "
            + "FROM ORDER_DISHES WHERE ORDER_ID = ?";

        BigDecimal total;

        try (Connection conn = DriverManager.getConnection(
                DB_URL, DB_USER, DB_PASSWD)) {

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, orderId);

                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    total = rs.getBigDecimal(1);

                    if (total == null) {
                        total = BigDecimal.ZERO;
                    }
                }
            }

            String updateSql =
                "UPDATE ORDERS SET TOTAL_PRICE = ? "
                + "WHERE ORDER_ID = ?";

            try (PreparedStatement ps =
                    conn.prepareStatement(updateSql)) {

                ps.setBigDecimal(1, total);
                ps.setInt(2, orderId);
                ps.executeUpdate();
            }
        }

        return total;
    }
}